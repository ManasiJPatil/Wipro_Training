package day123;

import java.util.Arrays;
import java.util.Random;

public class Task7a {

    public static void main(String[] args) {
        
        int size = 10;

        
        int[] array = InitializeArray(size);

        System.out.println("Original array: " + Arrays.toString(array));

        BruteForceSort(array);

        System.out.println("Sorted array: " + Arrays.toString(array));
    }

   
    public static int[] InitializeArray(int size) {
        int[] array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = i + 1; 
        }
        return array;
    }

   public static void BruteForceSort(int[] array) {
        int size = array.length;

        for (int i = 0; i < size - 1; i++) {
            
            int minIndex = i;
            for (int j = i + 1; j < size; j++) {
                if (array[j] < array[minIndex]) {
                    minIndex = j;
                }
            }

            int temp = array[i];
            array[i] = array[minIndex];
            array[minIndex] = temp;
        }
    }
}
