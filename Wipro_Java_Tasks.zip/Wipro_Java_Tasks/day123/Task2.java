package day123;

import java.util.Scanner;

public class Task2 {

	public static void main(String[] args) {
			// TODO Auto-generated method stub
			Scanner sc=new Scanner(System.in);
			int sum=0;
			int sub=0;
			int mul=1;
			
			while(true){
	        System.out.println("Enter count of Numbers : ");
	        int n=sc.nextInt();
	        System.out.println("Enter the numbers  ");
	        int[]array=new int[n];
	        for(int i=0;i<array.length;i++){
	        	 array[i]=sc.nextInt();
	        }
	        System.out.println("Enter operation you want to perform : \n1.Addition \n2.Substraction \n3.Multiplication \n4.Division");
	        int a=sc.nextInt();
	       
	        switch (a) {
			case 1:
				for(int i=0;i<n;i++){
					sum=sum+array[i];
				}
				System.out.println("Addition = "+sum);
				break;

			case 2:
				for(int i=0;i<n;i++){
					sub=sub-array[i];
				}
				System.out.println("Substratcion = "+sub);
				break;
				
			case 3:
				for(int i=0;i<n;i++){
					mul=mul*array[i];
				}
				System.out.println("Multiplication = "+mul);
				break;
			case 4:
			    if (n < 2) {
			        System.out.println("Error: Division requires at least two numbers.");
			    } else {
			        int div = array[0]; 
			        for (int i = 1; i < n; i++) {
			            if (array[i] == 0) {
			                System.out.println("Error: Division by zero is not allowed.");
			                break;
			            }
			            div = div/array[i];
			        }
			        System.out.println("Division = " + div);
			    }
			    break;
				
			default:
				System.out.println("Enter Valid Inputs");
				break;
			}
			}


	}

}
