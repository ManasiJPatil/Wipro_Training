package day123;

public class Task4 {
    
    public static void main(String[] args) {
        
        int size = 10; 
        
        int[] array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = i + 1; 
        }
        
       
        System.out.print("Original array: ");
        printArray(array);
        
    
        System.out.print("Reversed array: ");
        printArrayInReverse(array);
    }
    
  
    public static void printArray(int[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }
   
    public static void printArrayInReverse(int[] array) {
        for (int i = array.length - 1; i >= 0; i--) {
            System.out.print(array[i] + " ");
        }
        System.out.println(); 
    }
}
