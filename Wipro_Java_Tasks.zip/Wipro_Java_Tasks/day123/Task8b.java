package day123;
import java.util.Arrays;

public class Task8b {

	    public static void main(String[] args) {
	     
	        int n = 10;
	       
	        int[] fibonacciArray = new int[n];

	        for (int i = 0; i < n; i++) {
	            fibonacciArray[i] = findFibonacci(i);
	        }

	        System.out.println("First " + n + " elements of the Fibonacci sequence: " + Arrays.toString(fibonacciArray));
	    }

	   
	    public static int findFibonacci(int n) {
	     
	        if (n == 0) {
	            return 0; 
	        } else if (n == 1) {
	            return 1; 
	        }
	        return findFibonacci(n - 1) + findFibonacci(n - 2);
	    }
	


}
