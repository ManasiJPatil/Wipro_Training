package day123;

import java.util.Scanner;

public class Task1 {

	public static void main(String[] args) {
		 
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the first integer:");
        int a = scanner.nextInt();
        
        System.out.println("Enter the second integer:");
        int b = scanner.nextInt();
        
       
        a = a + b; 
        b = a - b; 
        a = a - b;      
        
        System.out.println("After swapping:");
        System.out.println("First integer: " + a);
        System.out.println("Second integer: " + b);
    

	}

}
