package day123;

public class Task7b {

    public static void main(String[] args) {
        
        int[] arr = {10, 25, 33, 47, 15, 62, 7, 19};

        int target = 33;

        int index = PerformLinearSearch(arr, target);

        if (index != -1) {
            System.out.println("Element " + target + " found at index: " + index);
        } else {
            System.out.println("Element " + target + " not found in the array.");
        }
    }

    public static int PerformLinearSearch(int[] arr, int target) {
        
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
               
                return i;
            }
        }

        return -1;
    }
}
