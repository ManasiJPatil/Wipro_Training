package day123;

import java.util.Scanner;

public class Task9 {

	 public static String concatenateReverseAndExtract(String str1, String str2, int length) {
		 
	        String cs = str1 + str2;
	        String rs = new StringBuilder(cs).reverse().toString();
	        int totalLength = rs.length();
	       if (totalLength == 0 || length > totalLength) {
	            
	            return "";
	        }
	        
	        int startIndex = (totalLength - length) / 2;
	        
	       return rs.substring(startIndex, startIndex + length);
	    }
	    
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	        System.out.println("Enter the first string:");
	        String str1 = scanner.nextLine();
	        
	        System.out.println("Enter the second string:");
	        String str2 = scanner.nextLine();
	        
	        System.out.println("Enter the length of the middle substring:");
	        int length = scanner.nextInt();
	        
	        String result = concatenateReverseAndExtract(str1, str2, length);
	        System.out.println("Concatenated, reversed, and extracted substring: " + result);
	    

	}


}
