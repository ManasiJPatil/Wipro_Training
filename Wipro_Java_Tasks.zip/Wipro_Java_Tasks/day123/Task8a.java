package day123;

import java.util.Arrays;

public class Task8a {

    public static void main(String[] args) {
       
        int[] array = {10, 25, 33, 47, 15, 62, 7, 19};

        int startIndex = 2;
        int endIndex = 6;

        int[] slicedArray = SliceArray(array, startIndex, endIndex);

        
        System.out.println("Original array: " + Arrays.toString(array));

        System.out.println("Sliced array from index " + startIndex + " to " + endIndex + ": " + Arrays.toString(slicedArray));
    }

    
    public static int[] SliceArray(int[] array, int startIndex, int endIndex) {
       
        if (startIndex < 0 || endIndex > array.length || startIndex > endIndex) {
            throw new IllegalArgumentException("Invalid indices for slicing the array.");
        }
        int length = endIndex - startIndex;

        int[] slicedArray = new int[length];

       
        for (int i = 0; i < length; i++) {
            slicedArray[i] = array[startIndex + i];
        }
        return slicedArray;
    }
}
