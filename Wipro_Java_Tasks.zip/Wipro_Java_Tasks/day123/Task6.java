package day123;

public class Task6 {


	    public static void main(String[] args) {
	        int[] arr = {1, 2, 3, 4, 5};

	       
	        int sum = SumArr(arr, arr.length);

	       
	        System.out.println("Sum of the elements in the array: " + sum);
	    }

	  
	    public static int SumArr(int[] array, int n) {
	        
	        if (n == 0) {
	            return 0;
	        }
	        return array[n - 1] + SumArr(array, n - 1);
	    }
	}


