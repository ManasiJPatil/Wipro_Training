package com.math.operations;

public class Main {

	public static void main(String[] args) {
		Addition addition = new Addition();
        Substraction subtraction = new Substraction();
        Multiplication multiplication = new Multiplication();
        Division division = new Division();

        // Demonstrate the usage of the operation methods
        int a = 10;
        int b = 5;

        System.out.println("Addition: " + addition.add(a, b));
        System.out.println("Subtraction: " + subtraction.substract(a, b));
        System.out.println("Multiplication: " + multiplication.multiply(a, b));
        System.out.println("Division: " + division.divide(a, b));

	}

}
