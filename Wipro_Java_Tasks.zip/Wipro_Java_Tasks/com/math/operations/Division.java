package com.math.operations;

public class Division {
	public int divide(int a, int b) {
        if (b == 0) {
            throw new ArithmeticException("Can not divide by zero");
        }
        return a / b;
    }

}
