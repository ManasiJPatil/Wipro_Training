package com.math.operations;

public class Substraction {
	 public int substract(int a, int b) {
	        return a - b;
	    }

}
