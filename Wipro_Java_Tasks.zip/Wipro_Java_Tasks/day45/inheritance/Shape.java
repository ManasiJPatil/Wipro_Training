package day45.inheritance;

public class Shape {
	
	public double area() {
		return 0.0;
	}
}
