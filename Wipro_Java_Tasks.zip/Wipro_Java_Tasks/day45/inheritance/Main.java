package day45.inheritance;

public class Main {

	public static void main(String[] args) {
		
		
	    Circle c=new Circle(5.0);
	    System.out.println("Circle Area:"+c.area());
	    
		Rectangle r=new Rectangle(5.5,7.2);
		System.out.println("Rectangle Area:"+r.area());

	}

}
