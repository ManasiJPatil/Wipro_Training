package day45.inheritance;

public class Rectangle extends Shape{
	double l;
	double b;
	Rectangle(double l,	double b){
		this.l=l;
		this.b=b;
	}
	public double area(){
		return l*b;
	}

}
