package day45.inheritance;

public class Circle extends Shape{
	
	double r;
	
	
	Circle(double r)
	{
	this.r=r;	
	}   
	
	public double area(){
		return 3.14*r*r;
		}
       
}
