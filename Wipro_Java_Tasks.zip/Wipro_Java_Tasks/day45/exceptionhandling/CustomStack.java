package day45.exceptionhandling;

import java.util.ArrayList;
import java.util.List;

public class CustomStack<T> {
    private List<T> stack; 

    public CustomStack() {
        this.stack = new ArrayList<>();
    }

    // Push operation: Adds an element to the top of the stack
    public void push(T element) {
        stack.add(element);
    }

    // Pop operation: Removes and returns the top element from the stack
    public T pop() {
        if (!stack.isEmpty()) {
            // Remove the last element and return it
            return stack.remove(stack.size() - 1);
        } else {
            // If the stack is empty, return null or throw an exception
            return null; // or throw new NoSuchElementException("Stack is empty");
        }
    }

    // Peek operation: Returns the top element of the stack without removing it
    public T peek() {
        if (!stack.isEmpty()) {
            // Return the last element without removing it
            return stack.get(stack.size() - 1);
        } else {
            // If the stack is empty, return null or throw an exception
            return null; // or throw new NoSuchElementException("Stack is empty");
        }
    }

    // IsEmpty operation: Checks whether the stack is empty
    public boolean isEmpty() {
        return stack.isEmpty();
    }

    // Main method to demonstrate the usage of the CustomStack class
    public static void main(String[] args) {
        // Create an instance of CustomStack
        CustomStack<Integer> stack = new CustomStack<>();

        // Push integers onto the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);

        // Display the stack contents and demonstrate the LIFO behavior
        System.out.println("Stack after pushing 5 elements: " + stack.stack);

        // Pop and display elements until the stack is empty
        System.out.println("Popping elements:");
        while (!stack.isEmpty()) {
            System.out.println(stack.pop());
        }

        // Stack should now be empty
        System.out.println("Is stack empty? " + stack.isEmpty());
    }
}

