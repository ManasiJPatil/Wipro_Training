package day45.exceptionhandling;

import java.util.LinkedList;
import java.util.Queue;

public class CustomQueue<T> {
    private Queue<T> queue; // Underlying data structure for the queue

    // Constructor to initialize the queue
    public CustomQueue() {
        this.queue = new LinkedList<>();
    }

    // Enqueue operation: Adds an element to the end of the queue
    public void enqueue(T element) {
        queue.add(element);
    }

    // Dequeue operation: Removes and returns the front element from the queue
    public T dequeue() {
        if (!queue.isEmpty()) {
            // Remove and return the first element in the queue
            return queue.poll();
        } else {
            // If the queue is empty, return null or throw an exception
            return null; // or throw new NoSuchElementException("Queue is empty");
        }
    }

    // Peek operation: Returns the front element of the queue without removing it
    public T peek() {
        if (!queue.isEmpty()) {
            // Return the first element without removing it
            return queue.peek();
        } else {
            // If the queue is empty, return null or throw an exception
            return null; // or throw new NoSuchElementException("Queue is empty");
        }
    }

    // IsEmpty operation: Checks whether the queue is empty
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    // Main method to demonstrate the usage of the CustomQueue class
    public static void main(String[] args) {
        // Create an instance of CustomQueue
        CustomQueue<Object> queue = new CustomQueue<>();

        // Enqueue different data types onto the queue
        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue("Hello");
        queue.enqueue(30);
        queue.enqueue("World");

        // Display the queue contents and demonstrate the FIFO behavior
        System.out.println("Queue after enqueuing elements: " + queue.queue);

        // Dequeue and display elements until the queue is empty
        System.out.println("Dequeuing elements:");
        while (!queue.isEmpty()) {
            System.out.println(queue.dequeue());
        }

        // Queue should now be empty
        System.out.println("Is queue empty? " + queue.isEmpty());
    }
}
